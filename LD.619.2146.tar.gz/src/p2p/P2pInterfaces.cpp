#include "P2pInterfaces.h"

namespace CryptoNote {

IP2pConnection::~IP2pConnection() {
}

}
