#include "IInputStream.h"
