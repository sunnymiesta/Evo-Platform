#pragma once

#include <string>

namespace System {
std::string lastErrorMessage();
std::string errorMessage(int);
}
